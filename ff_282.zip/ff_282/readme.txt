For further questions contact me at uberto@ubiland.net

GENERAL INFO:
Fractal Forge Freeware Open Source.
Draw your fractals, explore Mandelbrot Set easier and faster than ever. Export images, with JPG, PNG or BMP format.
Create and edit your favorite colors sequences or import Fractint Palettes. 
Avi creations to document your fractal tours.
Print Poster-size image tiling smaller ones.
Julia floating windows.
Orbits floating windows.
Post-processing graphic filters. 
Wallpaper exports. 
Several generating and coloring formulas coded in assembler.
Supports up to 4 CPU. 
Print Poster-size image tiling smaller ones.
Full screen mode.
Help and tutorial included. 
Delphi source at http://sourceforge.net/projects/fractalforge.

HARDWARE AND SOFTWARE REQUIREMENTS:
You need a x486 or better.
MS-Windows 9x, NT or later (included XP).

COPYRIGHT NOTICE:
Fractal Forge is an Open Source program. 
Copyrights are reserved to Uberto Barbini
You may use it on as many computers as you want.
You can also get the source and modify it, as far as you accompy three rules:
1) If you redistribute it you must send me a copy of your modified  source 
2) You must include this file and don't modify this license
3) You change the name of program and made clear it is different from FractalForge
Moreover if you print or publish (including web pages) FractalForge generated images you must acknowledge it.
Postcards and/or e-mails with suggestions or compliments are always welcome.
Please contact the author (by email) to include this program in large distribution as in newspapers, CD-ROMs, and floppies, OR send him a copy of the final distribution.

HOW TO CONTRIBUTE:
Apart for bug fixing I consider FF quite mature now, so I'm not planning any more release.
If you want I'll continue FF develop or want to "sponsorize" some features, I published a dvd wish list at amazon.com from that you can choose a gift for me. If you have no account on Amazon you can surely use another shop! ;)

FOR PROGRAMMERS:
If you have a programming question, please contact me by email (uberto@ubiland.net) or in Marco Cantu's newsgroups (http://www.dedonline.com). 

PER ITALIANI:
Fatemi sapere se ci sono volontari per la traduzione italiana di Fractal Forge.
